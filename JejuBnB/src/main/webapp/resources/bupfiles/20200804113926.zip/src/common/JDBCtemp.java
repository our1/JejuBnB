package common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.io.*;

public class JDBCtemp {
	
//	  public static Connection getConnection() {
//	  
//		  Connection conn = null;
//		  
//		  try {
//			    Class.forName("oracle.jdbc.driver.OracleDriver");
//			    conn = DriverManager.getConnection("jdbc:oralce:thin:@localhost:1521:xe", "student", "student");
//			    conn.setAutoCommit(false);
//	  
//		  } catch (Exception e) {
//			  e.printStackTrace();
//		  } 
//		  return conn;
//	  }
	
	public static Connection getConnection() {
		Connection conn = null;
		Properties prop = new Properties();
		
		try {
			// 톰캣이 구동하고 있는 현재 웹 프로젝트( 웹 앱플리케이션 )에서의 경로 지정이 필요함.
			// 또는 현재 실행하고 있는 클래스 위치에서 부터의 경로 지정도 가능함.
			
			// 현재 싱행중인 JDBCtemp.class 의 위치부터 파악함
			String currentPath = JDBCtemp.class.getResource("./").getPath();   // ./ : JDBC가있는 현재폴더
			prop.load(new FileReader(currentPath + "jdbc.properties"));
			
			
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String passwd = prop.getProperty("passwd");
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, passwd);
			conn.setAutoCommit(false);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		
		return conn;
	}
	


public static void close(Connection conn) {
	
	try {
		if (conn != null && !conn.isClosed()) {
			conn.close();
		} 
	}catch (Exception e) { 
		e.printStackTrace();
	}
} 

public static void close(Statement stmt) {
	
	try {
		if (stmt != null && !stmt.isClosed()) {
			stmt.close();
		} 
	}catch (Exception e) { 
		e.printStackTrace();
	}	
} 


public static void close(ResultSet rset) {
	
	try {
		if (rset != null && !rset.isClosed()) {
			rset.close();
		} 
	}catch (Exception e) { 
		e.printStackTrace();
	}
} 
	
	

public static void commit(Connection conn) {
	
	try {
		if (conn != null && !conn.isClosed()) {
			conn.commit();
		} 
	}catch (Exception e) { 
		e.printStackTrace();
	}
} 


public static void rollback(Connection conn) {
	
	try {
		if (conn != null && !conn.isClosed()) {
			conn.rollback();
		} 
	}catch (Exception e) { 
		e.printStackTrace();
	}
}

}