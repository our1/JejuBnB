package member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.model.service.MemberService;
import member.model.vo.Member;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class loginServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;

   /**
    * @see HttpServlet#HttpServlet()
    */
   public loginServlet() {
      super();
      // TODO Auto-generated constructor stub
   }

   /**
    * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
    *      response)
    */
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      // 전송온 값의 한글이 있다면 , 문자인코딩 처리한다.
      // 전송온 값 꺼내서 변수 또는 객체에 기록 저장함
      // 전송온 값들은 모두 REQUEST에 기록되어 전송이 온다.
      // 요청자의 정보는 RESPONSE에 기록되어 전손된다
      // String 변수 = request.getparameter("name속성에 설정한 이름");
      String userid = request.getParameter("userid");
      String userpwd = request.getParameter("userpwd");

      System.out.println(userid + "  <>  " + userpwd);

      // 모델 객체 선언 및 생성하고,
      MemberService mservice = new MemberService();
      Member loginMember = mservice.loginCheck(userid, userpwd);
      if (loginMember != null) {

         HttpSession session = request.getSession();
         System.out.println("생성 객체 id" + session.getId());
         session.setAttribute("loginMember", loginMember);

         response.sendRedirect("index.jsp");

      } else {
         // response.sendRedirect("views/common/error.jsp");
         RequestDispatcher view = request.getRequestDispatcher("views/common/error.jsp");
         request.setAttribute("message", "로그인 실패 또는 로그인 제한상태!");
         view.forward(request, response);
      }

   }

   /**
    * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
    *      response)
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      // TODO Auto-generated method stub
      doGet(request, response);
   }

}
