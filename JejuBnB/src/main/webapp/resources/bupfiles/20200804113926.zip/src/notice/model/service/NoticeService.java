package notice.model.service;

import notice.model.dao.NoticeDao;
import notice.model.vo.Notice;

import java.sql.Connection;
import java.util.ArrayList;

import member.model.vo.Member;

import static common.JDBCtemp.*;


public class NoticeService {
	
	// 의존성주입 
	private NoticeDao ndao = new NoticeDao();
	
	
	public NoticeService() {}
	
	public ArrayList<Notice> selectAll() {
		Connection conn = getConnection();
		ArrayList<Notice> list = ndao.selectList(conn);
		close(conn);
		return list;
	}
	
	public Notice selectNotice(int noticeNo) {
		Connection conn = getConnection();
		Notice notice = ndao.selectOne(conn, noticeNo);
		close(conn);
		return notice;
		
	}
	
	public int insertNotice(Notice notice) {
		Connection conn = getConnection();
		int result = ndao.insertNotice(conn, notice);
		if ( result > 0 ) {
			commit(conn);
		} else {
			rollback(conn);
		}
		return result;
	}
		
	
	public int updateNotice(Notice notice) {
		Connection conn = getConnection();
		int result = ndao.updateNotice(conn, notice);
		if ( result > 0 ) {
			commit(conn);
		} else {
			rollback(conn);
		}
		return result;
		
	}
	
	public int deleteNotice(int noticeNo) {
	Connection conn = getConnection();
	int result = ndao.deleteNotice(conn, noticeNo);
	if ( result > 0 ) {
		commit(conn);
	} else {
		rollback(conn);
	}
	return result;
	}

	public ArrayList<Notice> selectNewTop3() {
		Connection conn = getConnection();
		ArrayList<Notice> list = ndao.selectNewTop3(conn);
		close(conn);
		return list;
		
		
	}	
}
	

